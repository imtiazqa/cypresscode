//import LoginTest from 'cypress\support\commands.js'
it('LoginCases',()=>{
cy.LoginTest('admin','admin123')
})
