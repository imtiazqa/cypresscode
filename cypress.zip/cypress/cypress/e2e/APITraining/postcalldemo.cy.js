describe('Post call Approaches',()=>{
    it('Approach1- Hard Coded values', ()=>{
        const requestbody={
            name: "morpheus",
            job: "leader"
              }
        cy.request({method:'POST',url:'https://reqres.in/api/users',requestbody})
        .then((response)=>{
            //cy.writeFile('.\cypress\\fixtures\\test.json', response.body, 'binary')
            const contents = response.body
            cy.wait(500)
            expect(response.status).to.eq(201)
            cy.wait(500)
            expect(42).to.eq(42)
            cy.log(contents)
            //expect(response.body.tourist_name).to.eq("imtiaz")
            //cy.log(response.requestbody.tourist_name)
            //const jsonData = response.tourist_name
            //cy.log(jsonData)
            //cy.log(response.)
            //expect(response.body.tourist_name).to.eq(requestbody.tourist_name)
            //expect(response.body.tourist_email).to.eq('test5@gmail.com')
            //expect(response.body.tourist_location).to.eq('Paris')

        })

    })

})