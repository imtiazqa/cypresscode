describe("Authentication methods",()=>{
    let accesstoken="";
it("Basic Auth",()=>{
cy.request({mehod:'GET',url:"https://postman-echo.com/basic-auth",
auth:{username:'postman',password:'password'}}).then((response)=>{
    expect(response.status).to.eq(200)
    expect(response.body.authenticated).to.true


})

})
it("Digest Auth",()=>{
    cy.request({mehod:'GET',url:"https://postman-echo.com/basic-auth",
    auth:{username:'postman',password:'password',method:'digest'}}).then((response)=>{
        expect(response.status).to.eq(200)
        expect(response.body.authenticated).to.true
    
    
    })
    
    })

    it("Bearer Authenticcation",()=>{
        const token='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'
        cy.request({method:'GET',
        url:'https://api.github.com/user/repos',headers:{authorization:'bearer '+token}})
        .then((response)=>{
            expect(response.status).to.eq(200)
        })
    })

    it("API key ",()=>{
       // 1ccc224536cf5a81007c6a85307dde75
        cy.request({method:'GET',url:'https://api.openweathermap.org/data/2.5/weather?q=Delhi',
        qs:{appid:'1ccc224536cf5a81007c6a85307dde75'}})
        .then((response)=>{
            expect(response.status).to.eq(200)
        })
    
    })
it("oth2 authentication token",()=>{
cy.request({Method:'POST',url:'https://github.com/login/oauth/access_token',
qs:{client_id:'feb53a77dfb375fa5c83',
client_secret:'70345cdf628fe393f3027aa874ba52cf9a77e710',
code: '3aec007a2f6b02493403'}}).then((response)=>{
    cy.log(response.body.status)
    const param=response.body.split('&')
    cy.log(param)
    accesstoken=param[0].split("=")[1]
    //expect(response.status).to.eq(200)
    cy.log(accesstoken)
    accesstoken="Bearer "+accesstoken
    cy.log(accesstoken)

})
})

it("oth2 authentication get call",()=>{
    cy.request({Method:'GET',url:'https://api.github.com/user/repos',
    headers:{Authorization:accesstoken}}).then((response)=>{
        
        expect(response.status).to.eq(200)
        expect(response.body[0].id).to.eq(708656828)
        expect(response.body[0].full_name).to.eq('imtiazqa/githubactions')
        expect(response.body[0].name).to.eq('githubactions')

        //cy.log(response.body[0].name)
    
    })

    })
})

