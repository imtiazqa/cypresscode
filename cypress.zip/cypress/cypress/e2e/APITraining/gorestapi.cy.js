/*describe("GO rest API",()=>{
const token='Bearer 1b34a5b3ac803b99dfba18cf769bea647c4e7be1a2b9b5cb1e647f3cbd082d37'
it("Add,Update and delete API",()=>{
cy.request({method:'POST',url:'https://gorest.co.in/public/v2/users',body:{
    name:'imtiaz',
    gender:'male',
    email:Math.random().toString(5).substring(2)+"gmail.com",
    status:'active'
},headers:{
    authorization:token
}}).then(response.status).to.eq(200)
   const userid=reponse.body.id
   cy.request({method:'PUT',url:`https://gorest.co.in/public/v2/users${userid}`,
   body:{name:'Scott'},headers:{authorization:token}
}).then((response)=>{
    expect(response.status).to.eq(200)
    expect(response.body.name).to.eq('Scott')
    cy.request({method:'DELETE',url:`https://gorest.co.in/public/v2/users${userid}',
    headers:{authorization:token}})
    })*/


describe("GO rest API", () => {
    const token = 'Bearer 1b34a5b3ac803b99dfba18cf769bea647c4e7be1a2b9b5cb1e647f3cbd082d37'
    it("Add,Update and delete API", () => {
        cy.request({
            method: 'POST', url: 'https://gorest.co.in/public/v2/users', body: {
                name: 'imtiaz',
                gender: 'male',
                email: Math.random().toString(5).substring(2) + "@gmail.com",
                status: 'active'
            }, headers: {
                authorization: token
            }
        }).then((response)=>{
expect(response.status).to.eq(201)
const userid=response.body.id
cy.request({method:'PUT',url:`https://gorest.co.in/public/v2/users/${userid}`,
body:{name:'Scott'},headers:{authorization:token}
}).then((response)=>{
    expect(response.status).to.eq(200)
    expect(response.body.name).to.eq('Scott')
    cy.request({method:'DELETE',url:`https://gorest.co.in/public/v2/users/${userid}`, 
    headers:{authorization:token}})

        })
    })
})
})