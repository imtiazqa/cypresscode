describe('API method Tests',()=>{
    it('Get Method',()=>{
        cy.request('GET','https://jsonplaceholder.typicode.com/posts')
        .its('status')
        .should('equal',200)
        
    })
    it('Post Method',()=>{
        cy.request({ method:'Post',url:'https://jsonplaceholder.typicode.com/posts',body:{
    userId: 1,
    title: "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
    body: "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
    }}).its('status')
  .should('equal',201)
})
   it('Put request',()=>{
      cy.request({method:'PUT',url:'https://jsonplaceholder.typicode.com/posts/1',body:
        {
            "userId": 1,
            "id": 1,
            "title": "Update Test",
            "body": "Update Test"
          
      }})
      .its('status')
      .should('equal',200)
    })
    it('Delete Method',()=>{
        cy.request({Method:'DELETE',url:'http://jsonplaceholder.typicode.com/posts'})
        .its('status')
        .should('equal',200)
    })
   

})