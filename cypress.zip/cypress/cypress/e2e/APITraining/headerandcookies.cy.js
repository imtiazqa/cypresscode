
/// <reference types="Cypress" />
/*describe("Header and cookies",()=>{
before("Generate Token",()=>{

    let tokengen;

    cy.request({ method:'POST',url:'https://simple-books-api.glitch.me/apiclients/',
    headers:{'Content-type':'application/json'},
    body:{clientName: 'ABC',clientEmail: Math.random.toString(5).substring(2)+"@gmail.com"

    }
    
}).then((response)=>{
    tokengen=response.body.accessToken;
    

})


})
before("Create order",()=>{
    cy.request({ method:'POST',url:'https://simple-books-api.glitch.me/orders/',
    headers:{'Content-type':'application/json',
            'Authorization':'Bearer ' +tokengen},
    body:{bookid: 'QA',customerName: "Imtiaz"}
    }).then((response)=>{
    expect(response.status).to.eq(201)
    expect(response.body.created).to.eq(true)
    

})
})

it("Display order",()=>{
    cy.request({method:'GET',url: 'https://simple-books-api.glitch.me/orders/',
    headers:{'Content-type':'application/json',
    'Authorization':'Bearer ' +tokengen}
    //,cookies:{
      //  cookiename: 'ImtiazTests'
    })
    .then((response)=>{
        expect(response.status).to.eq(200)
        expect(response.body).has.length(1)
    })


})

})*/

describe("Get API users",()=>{
    it(" Display user via token",()=>{
        cy.request({method: 'GET',url: 'https://gorest.co.in/public/v2/users',
        headers:
        { Authorization:"Bearer 4a971a1968db7dd5beb6b427a1326eeb4bd613330a00914e447b4dc7888d5abc" }
    }).then((res)=>{
        expect(res.status).to.eq(200)
        expect(res.body[0].name).to.eq("Darshan Arora")
        expect(res.body[0].email).to.eq("darshan_arora@kuvalis.test")
        //cy.log(res.statusText)
        //cy.log(res.body)
        
        
    })
    })
})
