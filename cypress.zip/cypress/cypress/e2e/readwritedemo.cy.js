before(function(){

    const qa_data=cy.fixture('example.json').as('text')
    //cy.log(this.qa_data.name)
})
it("Read from fixture",()=>{
    cy.fixture('example.json').then((data)=>{
        cy.log(data.name)
        cy.log(data.email)


    })
})

it("Read File by using readfile function()", function(){
    cy.readFile('./cypress/fixtures/example.json').then((data)=>{
        cy.log(data.name)
        cy.log(data.email)
    })

})
it('Write the file by using writefunction()',function(){
    cy.writeFile('test.txt','I am Imtiaz \n')
    cy.writeFile('test.txt','I am learning cypress',{flag:'a+'})
})