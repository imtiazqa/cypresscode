/*User Listing related Test Cases */
describe('User Listing',()=> {

    it('List Users',()=>{
        cy.request("GET", "https://reqres.in/api/users?page=2").should((response) => {
            expect(response.status).to.eq(200);
    });});
    it('Single User',()=>{
        cy.request("GET", "https://reqres.in/api/users/2").should((response) => {
            expect(response.status).to.eq(200);
    });});
    it('Single User not found',()=>{
        cy.request({Method:'GET', url: "https://reqres.in/api/users/23",failOnStatusCode: false}).should((response) => {
            expect(response.status).to.eq(404);
    });});
    /*it('Single User not found',()=>{
        cy.request("GET", "https://reqres.in/api/users/23").should((response) => {
            expect(response.status).to.eq(404);
    });});*/
    it('Delayed Response',()=>{
        cy.request("GET", "https://reqres.in/api/users?delay=3").should((response) => {
            expect(response.status).to.eq(200);
    });});
})

/*Resources related Test Cases */
describe('Resources Listing',()=> {

    it('List Resources',()=>{
        cy.request("GET", "https://reqres.in/api/unknown").should((response) => {
            expect(response.status).to.eq(200);
    });});
    it('List Single Resource',()=>{
        cy.request("GET", "https://reqres.in/api/unknown/2").should((response) => {
            expect(response.status).to.eq(200);
    });});
    it('Single Resource not found',()=>{
        cy.request({Method:'GET', url:"https://reqres.in/api/unknown/23",failOnStatusCode: false}).should((response) => {
            expect(response.status).to.eq(404);
    });});

    /*it('Single Resource not found',()=>{
        cy.request("GET", "https://reqres.in/api/unknown/23").should((response) => {
            expect(response.status).to.eq(404);
    });});*/
})


/*User management related Test Cases */
describe('User management',()=> {

    it("Create User", () => {
        cy.request("POST", "https://reqres.in/api/users", {
          name: "morpheus",
          job: "leader",
        }).should((response) => {
          expect(response.status).to.eq(201);
        });
      });
      it("Update user", () => {
        cy.request("PUT", "https://reqres.in/api/users/2", {
          name: "morpheus",
          job: "zion resident",
        }).should((response) => {
          expect(response.status).to.eq(200);
        });
      });

      it("patch Update user", () => {
        cy.request("PATCH", "https://reqres.in/api/users/2", {
          name: "morpheus",
          job: "zion resident",
        }).should((response) => {
          expect(response.status).to.eq(200);
        });
      });
      it("DELETE User", () => {
        cy.request("DELETE", "https://reqres.in/api/users/2").should((response) => {
          expect(response.status).to.eq(204);
        });
      });      
})

/*Registration related Test Cases */
describe('Registration',()=> {

    it("Register Successfully", () => {
        cy.request("POST", "https://reqres.in/api/register", {
            email: "eve.holt@reqres.in",
            password: "pistol",
        }).should((response) => {
          expect(response.status).to.eq(200);
        });
      });
      it("Register Unsuccessfully", () => {
        cy.request({method:'POST',url: "https://reqres.in/api/register",failOnStatusCode: false}, {
            email: "sydney@fife"
        }).should((response) => {
          expect(response.status).to.eq(400);
        });
      });
      /*it("Register Unsuccessfully", () => {
        cy.request("POST", "https://reqres.in/api/register", {
            email: "sydney@fife"
        }).should((response) => {
          expect(response.status).to.eq(400);
        });
      });*/
})


/*Login related Test Cases */
describe('Login',()=> {

    it("Login Successfully", () => {
        cy.request("POST", "https://reqres.in/api/login", {
            email: "eve.holt@reqres.in",
            password: "cityslicka",
        }).should((response) => {
          expect(response.status).to.eq(200);
        });
      });
      it("Login Unsuccessfully", () => {
        cy.request({method:'POST',url: "https://reqres.in/api/register",failOnStatusCode: false}, {
            email: "peter@klaven"
        }).should((response) => {
          expect(response.status).to.eq(400);
        });
      });
      /*it("Login Unsuccessfully", () => {
        cy.request("POST", "https://reqres.in/api/register", {
            email: "peter@klaven"
        }).should((response) => {
          expect(response.status).to.eq(400);
        });
      });*/
})