import { loginpage} from "../pages/loginpage"
const pompage=new loginpage()
it('POM' , () =>{
    cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
   /* cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type('admin')
    cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type('admin123')
    cy.get('.oxd-button').click()*/
     pompage.enterusername()
     pompage.enterpassword()
     pompage.clicklogin()
}) 
