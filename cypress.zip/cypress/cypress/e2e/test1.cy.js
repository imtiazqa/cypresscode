it('google search', () => {
    cy.visit('https://google.com')
    cy.get('#APjFqb',{timeout:5000}).type('Step by step automation of cypress{enter}')
    cy.wait(5000)
    cy.contains('Videos').click()
  })