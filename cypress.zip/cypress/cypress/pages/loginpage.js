export class loginpage{


    enterusername(){
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type('admin')
    }
    enterpassword(){
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type('admin123')

    }
    clicklogin()
    {
        cy.get('.oxd-button').click()

    }
}